import React from "react";

export function Title() {
  return <h1>Adopt Me!</h1>;
}